<style>
    li {
        list-style-type: none;
    }
</style>

<!-- Authentication Links -->

<?php if(auth()->guard()->guest()): ?>
<li class="text-white" style="position: fixed; right: 1%;">
    <a class="" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
</li>
<?php if(Route::has('register')): ?>
<li class="text-white" style="position: fixed; right: 1%;top: 3%">
    <a class="" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
</li>
<?php endif; ?>
<?php else: ?>
<div class="dropdown" style="position: fixed; right: 1%;">
    <button class="btn dropdown-toggle text-white" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
        <?php echo e(Auth::user()->name); ?>

    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" style="color: #FFFFFF;" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(route('logout')); ?></a></li>
    </ul>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
    </form>
</div>
<?php endif; ?><?php /**PATH C:\laravel\ApoloBytes\resources\views/partials/authentication.blade.php ENDPATH**/ ?>